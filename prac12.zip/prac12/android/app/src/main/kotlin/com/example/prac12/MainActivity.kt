package com.example.prac12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
