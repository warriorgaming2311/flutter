package com.example.prac8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
