import 'package:flutter/material.dart';

void main() {
  runApp(const Prac8());
}

class Prac8 extends StatelessWidget {
  const Prac8({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: ThreeSectionsScreen(),
    );
  }
}

class ThreeSectionsScreen extends StatefulWidget {
  const ThreeSectionsScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _ThreeSectionsScreenState createState() => _ThreeSectionsScreenState();
}

class _ThreeSectionsScreenState extends State<ThreeSectionsScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );

    _animation = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Three Sections App'),
      ),
      body: FadeTransition(
        opacity: _animation,
        child: Column(
          children: [
            // Header Section
            Container(
              height: 100,
              color: Colors.blue,
              child: const Center(
                child: Text(
                  'Header Section',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            // Content Section
            Expanded(
              child: Container(
                color: Colors.green,
                child: const Center(
                  child: Text(
                    'Content Section',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            // Footer Section
            Container(
              height: 100,
              color: Colors.red,
              child: const Center(
                child: Text(
                  'Footer Section',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
