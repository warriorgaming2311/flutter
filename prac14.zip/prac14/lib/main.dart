import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Restaurant Menu',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final List<MenuItem> _menuItems = [
    MenuItem('Burger', 10.99),
    MenuItem('Pizza', 12.99),
    MenuItem('Salad', 8.99),
    MenuItem('Sandwich', 9.99),
    MenuItem('Fries', 4.99),
    MenuItem('Soda', 2.99),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Restaurant Menu'),
      ),
      body: ListView.builder(
        itemCount: _menuItems.length,
        itemBuilder: (context, index) {
          return Column(
            children: [
              ListTile(
                title: Text(_menuItems[index].name),
                subtitle: Text('\$${_menuItems[index].price}'),
                trailing: ElevatedButton(
                  onPressed: () {
                    // Add to cart logic here
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Added to cart')),
                    );
                  },
                  child: const Text('Add to Cart'),
                ),
              ),
              const Divider(),
            ],
          );
        },
      ),
    );
  }
}

class MenuItem {
  String name;
  double price;

  MenuItem(this.name, this.price);
}