package com.example.prac14

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
