package com.example.prac15

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
