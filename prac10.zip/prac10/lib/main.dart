import 'package:flutter/material.dart';

void main() {
  runApp(const P10());
}

class P10 extends StatelessWidget {
  const P10({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product List',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ProductListScreen(),
    );
  }
}

class ProductListScreen extends StatelessWidget {
  final List<Map<String, dynamic>> products = [
    {
      'name': 'Laptop',
      'price': 1200,
      'description': 'High-performance laptop',
      'image':
          'https://unsplash.com/photos/laptop-computer-beside-coffee-mug-j4uuKnN43_M'
    },
    {
      'name': 'Smartphone',
      'price': 800,
      'description': 'Latest model smartphone',
      'image': 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Smartphone'
    },
    {
      'name': 'Headphones',
      'price': 150,
      'description': 'Noise-cancelling headphones',
      'image': 'https://via.placeholder.com/150/00FF00/000000?text=Headphones'
    },
    {
      'name': 'Smartwatch',
      'price': 200,
      'description': 'Waterproof smartwatch',
      'image': 'https://via.placeholder.com/150/FFFF00/000000?text=Smartwatch'
    },
    {
      'name': 'Tablet',
      'price': 400,
      'description': 'Lightweight tablet with stylus',
      'image': 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Tablet'
    },
  ];

  ProductListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Products'),
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Card(
            elevation: 5,
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: ListTile(
              leading: Image.network(
                product['image'],
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(
                product['name'],
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                '\$${product['price']}',
                style: TextStyle(
                  color: Colors.grey[700],
                ),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  PageRouteBuilder(
                    pageBuilder: (context, animation, secondaryAnimation) =>
                        ProductDetailScreen(product: product),
                    transitionsBuilder:
                        (context, animation, secondaryAnimation, child) {
                      var fadeIn =
                          Tween(begin: 0.0, end: 1.0).animate(animation);
                      var scaleIn =
                          Tween(begin: 0.8, end: 1.0).animate(animation);

                      return FadeTransition(
                        opacity: fadeIn,
                        child: ScaleTransition(
                          scale: scaleIn,
                          child: child,
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class ProductDetailScreen extends StatelessWidget {
  final Map<String, dynamic> product;

  const ProductDetailScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product['name']),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Image.network(
                product['image'],
                height: 200,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              product['name'],
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              '\$${product['price']}',
              style: const TextStyle(
                fontSize: 22,
                color: Colors.green,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              product['description'],
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[800],
              ),
            ),
          ],
        ),
      ),
    );
  }
}














// import 'package:flutter/material.dart';

// void main() {
//   runApp(P10());
// }

// class P10 extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Product List',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: ProductListScreen(),
//     );
//   }
// }

// class ProductListScreen extends StatefulWidget {
//   @override
//   _ProductListScreenState createState() => _ProductListScreenState();
// }

// class _ProductListScreenState extends State<ProductListScreen> {
//   final List<Map<String, dynamic>> products = [
//     {
//       'name': 'Laptop',
//       'price': 1200,
//       'description': 'High-performance laptop',
//       'image': 'https://via.placeholder.com/150/0000FF/808080?text=Laptop'
//     },
//     {
//       'name': 'Smartphone',
//       'price': 800,
//       'description': 'Latest model smartphone',
//       'image': 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Smartphone'
//     },
//     {
//       'name': 'Headphones',
//       'price': 150,
//       'description': 'Noise-cancelling headphones',
//       'image': 'https://via.placeholder.com/150/00FF00/000000?text=Headphones'
//     },
//     {
//       'name': 'Smartwatch',
//       'price': 200,
//       'description': 'Waterproof smartwatch',
//       'image': 'https://via.placeholder.com/150/FFFF00/000000?text=Smartwatch'
//     },
//     {
//       'name': 'Tablet',
//       'price': 400,
//       'description': 'Lightweight tablet with stylus',
//       'image': 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Tablet'
//     },
//   ];

//   final List<Map<String, dynamic>> cart = [];

//   void addToCart(Map<String, dynamic> product) {
//     setState(() {
//       final existingItem = cart.firstWhere(
//           (item) => item['name'] == product['name'],
//           orElse: () => {});
//       if (existingItem.isNotEmpty) {
//         existingItem['quantity'] += 1;
//       } else {
//         cart.add({
//           ...product,
//           'quantity': 1,
//         });
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Products'),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.shopping_cart),
//             onPressed: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) =>
//                       CartScreen(cart: cart, onUpdateCart: updateCart),
//                 ),
//               );
//             },
//           )
//         ],
//       ),
//       body: ListView.builder(
//         itemCount: products.length,
//         itemBuilder: (context, index) {
//           final product = products[index];
//           return Card(
//             elevation: 5,
//             margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
//             child: ListTile(
//               leading: Image.network(
//                 product['image'],
//                 width: 50,
//                 height: 50,
//                 fit: BoxFit.cover,
//               ),
//               title: Text(
//                 product['name'],
//                 style: TextStyle(
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               subtitle: Text(
//                 '\$${product['price']}',
//                 style: TextStyle(
//                   color: Colors.grey[700],
//                 ),
//               ),
//               trailing: IconButton(
//                 icon: Icon(Icons.add_shopping_cart),
//                 onPressed: () {
//                   addToCart(product);
//                 },
//               ),
//               onTap: () {
//                 Navigator.push(
//                   context,
//                   PageRouteBuilder(
//                     pageBuilder: (context, animation, secondaryAnimation) =>
//                         ProductDetailScreen(product: product),
//                     transitionsBuilder:
//                         (context, animation, secondaryAnimation, child) {
//                       var fadeIn =
//                           Tween(begin: 0.0, end: 1.0).animate(animation);
//                       var scaleIn =
//                           Tween(begin: 0.8, end: 1.0).animate(animation);

//                       return FadeTransition(
//                         opacity: fadeIn,
//                         child: ScaleTransition(
//                           scale: scaleIn,
//                           child: child,
//                         ),
//                       );
//                     },
//                   ),
//                 );
//               },
//             ),
//           );
//         },
//       ),
//     );
//   }

//   void updateCart(String productName, int quantity) {
//     setState(() {
//       final product = cart.firstWhere((item) => item['name'] == productName);
//       if (quantity == 0) {
//         cart.remove(product);
//       } else {
//         product['quantity'] = quantity;
//       }
//     });
//   }
// }

// class ProductDetailScreen extends StatelessWidget {
//   final Map<String, dynamic> product;

//   ProductDetailScreen({required this.product});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(product['name']),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: <Widget>[
//             Center(
//               child: Image.network(
//                 product['image'],
//                 height: 200,
//                 fit: BoxFit.cover,
//               ),
//             ),
//             SizedBox(height: 20),
//             Text(
//               product['name'],
//               style: TextStyle(
//                 fontSize: 28,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             SizedBox(height: 10),
//             Text(
//               '\$${product['price']}',
//               style: TextStyle(
//                 fontSize: 22,
//                 color: Colors.green,
//                 fontWeight: FontWeight.w600,
//               ),
//             ),
//             SizedBox(height: 20),
//             Text(
//               product['description'],
//               style: TextStyle(
//                 fontSize: 18,
//                 color: Colors.grey[800],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class CartScreen extends StatelessWidget {
//   final List<Map<String, dynamic>> cart;
//   final Function(String, int) onUpdateCart;

//   CartScreen({required this.cart, required this.onUpdateCart});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Your Cart'),
//       ),
//       body: ListView.builder(
//         itemCount: cart.length,
//         itemBuilder: (context, index) {
//           final product = cart[index];
//           return Card(
//             margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
//             elevation: 3,
//             child: ListTile(
//               leading: Image.network(
//                 product['image'],
//                 width: 50,
//                 height: 50,
//                 fit: BoxFit.cover,
//               ),
//               title: Text(
//                 product['name'],
//                 style: TextStyle(
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               subtitle: Row(
//                 children: [
//                   Text(
//                     '\$${product['price']}',
//                     style: TextStyle(
//                       color: Colors.grey[700],
//                     ),
//                   ),
//                   SizedBox(width: 20),
//                   Text(
//                     'x${product['quantity']}',
//                     style: TextStyle(
//                       color: Colors.grey[700],
//                     ),
//                   ),
//                 ],
//               ),
//               trailing: Row(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   IconButton(
//                     icon: Icon(Icons.remove),
//                     onPressed: () {
//                       if (product['quantity'] > 1) {
//                         onUpdateCart(product['name'], product['quantity'] - 1);
//                       } else {
//                         onUpdateCart(product['name'], 0);
//                       }
//                     },
//                   ),
//                   IconButton(
//                     icon: Icon(Icons.add),
//                     onPressed: () {
//                       onUpdateCart(product['name'], product['quantity'] + 1);
//                     },
//                   ),
//                   IconButton(
//                     icon: Icon(Icons.delete),
//                     onPressed: () {
//                       onUpdateCart(product['name'], 0);
//                     },
//                   ),
//                 ],
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }