package com.example.prac11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
