import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _currentQuestion = 0;
  int _score = 0;
  final List<Question> _questions = [
    Question('What is the capital of France?', ['Paris', 'London', 'Berlin', 'Rome'], 0),
    Question('What is the largest planet in our solar system?', ['Earth', 'Saturn', 'Jupiter', 'Uranus'], 2),
    Question('What is the smallest country in the world?', ['Vatican City', 'Monaco', 'Nauru', 'Tuvalu'], 0),
    // Add more questions here
  ];

  void _nextQuestion() {
    setState(() {
      _currentQuestion++;
    });
  }

  void _answerQuestion(int answerIndex) {
    if (answerIndex == _questions[_currentQuestion].correctAnswer) {
      setState(() {
        _score++;
      });
    }
    _nextQuestion();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quiz App'),
      ),
      body: _currentQuestion < _questions.length
          ? Column(
              children: [
                Text(_questions[_currentQuestion].question),
                ..._questions[_currentQuestion].options.map((option) => ElevatedButton(
                      onPressed: () {
                        _answerQuestion(_questions[_currentQuestion].options.indexOf(option));
                      },
                      child: Text(option),
                    )),
              ],
            )
          : Center(
              child: Text('Your score is $_score/${_questions.length}'),
            ),
    );
  }
}

class Question {
  String question;
  List<String> options;
  int correctAnswer;

  Question(this.question, this.options, this.correctAnswer);
}