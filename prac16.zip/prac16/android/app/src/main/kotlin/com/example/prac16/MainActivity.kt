package com.example.prac16

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
